﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace VolunteerManagment.Migrations
{
    /// <inheritdoc />
    public partial class ReportsFix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
